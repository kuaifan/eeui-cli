//
//  WebPluginDemoModule.h
//  Pods
//

#import <Foundation/Foundation.h>
#import "WeexSDK.h"

@interface WebPluginDemoModule : NSObject

@end
