//
//  AppPluginDemoModule.h
//  Pods
//

#import <Foundation/Foundation.h>
#import "WeexSDK.h"

@interface AppPluginDemoModule : NSObject <WXModuleProtocol>


@end
