//
//  PluginDemoEntry.h
//  Pods
//

#import <Foundation/Foundation.h>

@interface PluginDemoEntry : NSObject

@end
